const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  mainNav.classList.toggle("open");
  menuToggle.textContent = mainNav.classList.contains("open") ? "×" : "☰";
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.textContent = "☰";
}));
document.getElementById("year").textContent = new Date().getFullYear();

const cart = {};
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
function renderCart() {
  const entries = Object.entries(cart);
  const count = entries.reduce((sum, [, qty]) => sum + qty, 0);
  cartCount.textContent = count;
  if (!entries.length) {
    cartItems.innerHTML = '<p class="empty-cart">لسه مفيش عطور في السلة. اختار عطرك من المجموعة واضغط ＋</p>';
    return;
  }
  cartItems.innerHTML = entries.map(([name, qty]) => `
    <div class="cart-row">
      <div><strong>${name}</strong><small>50 مل · السعر يتم تأكيده عبر واتساب</small></div>
      <div class="quantity-controls">
        <button type="button" data-action="minus" data-name="${name}" aria-label="تقليل الكمية">−</button>
        <b>${qty}</b>
        <button type="button" data-action="plus" data-name="${name}" aria-label="زيادة الكمية">＋</button>
      </div>
    </div>`).join("");
}
document.querySelectorAll(".add-to-cart").forEach(button => {
  button.addEventListener("click", () => {
    const name = button.dataset.product;
    cart[name] = (cart[name] || 0) + 1;
    renderCart();
    document.getElementById("order").scrollIntoView({behavior:"smooth", block:"start"});
  });
});
cartItems.addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const name = button.dataset.name;
  if (button.dataset.action === "plus") cart[name] = (cart[name] || 0) + 1;
  if (button.dataset.action === "minus") {
    cart[name] = (cart[name] || 0) - 1;
    if (cart[name] <= 0) delete cart[name];
  }
  renderCart();
});
document.getElementById("checkoutForm").addEventListener("submit", event => {
  event.preventDefault();
  const entries = Object.entries(cart);
  if (!entries.length) {
    alert("من فضلك اختار عطر واحد على الأقل من المجموعة.");
    return;
  }
  const data = new FormData(event.currentTarget);
  const orderLines = entries.map(([name, qty]) => `- ${name} (50 مل) × ${qty}`).join("\n");
  const message = [
    "مرحباً RAWNAQ، عندي طلب جديد:",
    "",
    "العطور:",
    orderLines,
    "",
    `الاسم: ${data.get("customer")}`,
    `رقم الموبايل: ${data.get("phone")}`,
    `المحافظة / المدينة: ${data.get("city")}`,
    `العنوان: ${data.get("address")}`,
    `طريقة الدفع: ${data.get("payment")}`,
    `ملاحظات: ${data.get("notes") || "لا يوجد"}`,
    "",
    "من فضلكم أكدوا السعر وتكلفة الشحن والإجمالي قبل تأكيد الطلب."
  ].join("\n");
  window.open("https://wa.me/201505422642?text=" + encodeURIComponent(message), "_blank");
});
